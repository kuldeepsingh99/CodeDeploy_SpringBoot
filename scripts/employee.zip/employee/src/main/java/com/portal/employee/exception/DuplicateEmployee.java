package com.portal.employee.exception;

/**
 * Duplicate Employee Exception
 * @author Kuldeep
 *
 */
public class DuplicateEmployee extends Exception {

	private static final long serialVersionUID = 1L;

	public DuplicateEmployee(String s) {
		super(s);
	}
}
