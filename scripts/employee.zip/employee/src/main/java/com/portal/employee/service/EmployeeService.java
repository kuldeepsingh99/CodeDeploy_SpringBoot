package com.portal.employee.service;

import java.util.List;

import com.portal.employee.model.Employee;
import com.portal.employee.vo.EmployeeVO;

public interface EmployeeService {

	/**
	 * This method add employee
	 * @param employeeVO EmployeeVO
	 * @return 1 - Success, 2 - Duplicate Employee, 3 - Failure 
	 */
	public String addEmployee(EmployeeVO employeeVO);
	
	/**
	 * This method update employee
	 * @param employeeVO EmployeeVO
	 * @return 1 - Success, 3 - Failure, 4 - Not found 
	 */
	public String updateEmployee(EmployeeVO employeeVO);
	
	/**
	 * This method will delete employee
	 * @param employeeVO EmployeeVO
	 * @return 1 - success, 3 - Failure, 4 - Not found 
	 */
	public String deleteEmployee(EmployeeVO employeeVO);
	
	/**
	 * This method will search employee by email
	 * @param email Email
	 * @return employee
	 */
	public Employee searchEmployeeByEmail(String email);
	
	/**
	 * This method will search all employee by exact name
	 * @param name employee name
	 * @return List of employee
	 */
	public List<Employee> searchEmployeeByName(String name);
	
	/**
	 * This method will search all employee by name match
	 * @param name employee name
	 * @return List of employee
	 */
	public List<Employee> searchAllEmployeeByName(String name);
	
	/**
	 * This method will search all employee by exact name and employee status
	 * @param name employee name
	 * @param status employee status
	 * @return List of employee
	 */
	public List<Employee> searchEmployeeByNameAndActive(String name, String status);

	/**
	 * This method change employee status
	 * @param id employee unique id
	 * @param status 1- active, 0 - disable
	 * @return 1 - success, 3 - Failure, 4 - Not found 
	 */
	public String changeStatus(String id, String status);
}
