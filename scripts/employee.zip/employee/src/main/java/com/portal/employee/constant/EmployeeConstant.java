package com.portal.employee.constant;

public interface EmployeeConstant {

	String SUCCESS = "1";
	String DUPLICATE = "2";
	String FAILURE = "3";
	String NOTFOUND = "4";
}
