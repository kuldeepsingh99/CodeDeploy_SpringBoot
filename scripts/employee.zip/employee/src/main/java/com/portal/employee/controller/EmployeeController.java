package com.portal.employee.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.portal.employee.model.Employee;
import com.portal.employee.service.EmployeeService;
import com.portal.employee.vo.EmployeeVO;


@RestController
@RequestMapping(value = "/customer")
public class EmployeeController {

	@Autowired
	EmployeeService employeeService;
	
	/**
	 * This method creates new Employee
	 * @param employeeVO - EmployeeVO
	 * @return 1 - Success, 2 - Duplicate Employee, 3 - Failure 
	 */
	@RequestMapping(value = "/addemployee", method = { RequestMethod.POST })
	public String addemployee(@RequestBody EmployeeVO employeeVO) {
		// Validation Logic
		return employeeService.addEmployee(employeeVO);
	}
	
	/**
	 * This method updates Employee, this will only update Name and Employee id
	 * @param employeeVO - EmployeeVO (empId and name)
	 * @return 1 - Success, 3 - Failure, 4 - Not found 
	 */
	@RequestMapping(value = "/updateemployee", method = { RequestMethod.POST })
	public String updateemployee(@RequestBody EmployeeVO employeeVO) {
		// Validation Logic
		return employeeService.updateEmployee(employeeVO);
	}
	
	/**
	 * This method deletes Employee if present
	 * @param employeeVO - EmployeeVO (id is mandatory)
	 * @return 1 - success, 3 - Failure, 4 - Not found 
	 */
	@RequestMapping(value = "/deleteemployee", method = { RequestMethod.POST })
	public String deleteemployee(@RequestBody EmployeeVO employeeVO) {
		// Validation Logic
		return employeeService.deleteEmployee(employeeVO);
	}
	
	/**
	 * This method search Employee by email
	 * @param employeeVO - EmployeeVO (mandatory:- email)
	 * @return Employee object
	 */
	@RequestMapping(value = "/searchbyemail", method = { RequestMethod.GET })
	public Employee searchbyemail(@RequestBody EmployeeVO employeeVO) {
		// Validation Logic
		return employeeService.searchEmployeeByEmail(employeeVO.getEmailId());
	}
	
	/**
	 * This method will search all employee by exact name
	 * @param employeeVO - EmployeeVO (Mandatory:- name)
	 * @return List<Employee> List of employee
	 */
	@RequestMapping(value = "/searchbyname", method = { RequestMethod.GET })
	public List<Employee> searchbyname(@RequestBody EmployeeVO employeeVO) {
		// Validation Logic
		return employeeService.searchEmployeeByName(employeeVO.getName());
	}
	
	/**
	 * This method will search all employee by name match
	 * @param employeeVO - EmployeeVO (Mandatory:- name)
	 * @return
	 */
	@RequestMapping(value = "/searchallbyname", method = { RequestMethod.GET })
	public List<Employee> searchallbyname(@RequestBody EmployeeVO employeeVO) {
		// Validation Logic
		return employeeService.searchAllEmployeeByName(employeeVO.getName());
	}
	
	/**
	 * This method will search all employee by exact name and employee status(1-active, 0-inactive)
	 * @param employeeVO - EmployeeVO(Mandatory:- name, status)
	 * @return
	 */
	@RequestMapping(value = "/searchbyname/status", method = { RequestMethod.GET })
	public List<Employee> searchactiveemployeebyname(@RequestBody EmployeeVO employeeVO) {
		// Validation Logic
		return employeeService.searchEmployeeByNameAndActive(employeeVO.getName(), employeeVO.getStatus());
	}
	
	/**
	 * This method change the employee status
	 * @param employeeVO - EmployeeVO(id, status(1-active, 0-inactive)
	 * @return 1 - Success, 3 - Failure, 4 - Not found 
	 */
	@RequestMapping(value = "/changestatus", method = { RequestMethod.POST })
	public String disableemployee(@RequestBody EmployeeVO employeeVO) {
		// Validation Logic
		return employeeService.changeStatus(employeeVO.getId(), employeeVO.getStatus());
	}
}
