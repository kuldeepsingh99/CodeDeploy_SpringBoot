package com.portal.employee.service.imp;

import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.portal.employee.constant.EmployeeConstant;
import com.portal.employee.model.Employee;
import com.portal.employee.repository.EmployeeRepository;
import com.portal.employee.service.EmployeeService;
import com.portal.employee.vo.EmployeeVO;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	private static final Logger LOGGER = LoggerFactory.getLogger(EmployeeServiceImpl.class);

	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public String addEmployee(EmployeeVO employeeVO) {

		LOGGER.info("Start employee creation");

		try {
			/* Check if we already have employee with same email */
			Employee existingEmployee = employeeRepository.findByEmail(employeeVO.getEmailId());

			if (null == existingEmployee) {
				Employee emp = new Employee();
				emp.setName(employeeVO.getName());
				emp.setEmail(employeeVO.getEmailId());
				emp.setEmployeeId(employeeVO.getEmpId());
				emp.setStatus(1);

				Employee employeeRecord = employeeRepository.save(emp);

				if (null != employeeRecord) {
					// send notification mail to employee and admin
				}
				return EmployeeConstant.SUCCESS;
			} else {
				LOGGER.info("Duplicate employee found");
				return EmployeeConstant.DUPLICATE;
			}
		} catch (Exception e) {
			LOGGER.error("Exception occured creating employee", e);
			return EmployeeConstant.FAILURE;
		}
	}

	@Override
	public String updateEmployee(EmployeeVO employeeVO) {

		LOGGER.info("Start employee update ");

		try {
			Optional<Employee> emp = employeeRepository.findById(Integer.parseInt(employeeVO.getId()));
			if (emp.isPresent()) {
				Employee employee = emp.get();
				if(!StringUtils.isEmpty(employeeVO.getEmpId())) {
					employee.setEmployeeId(employeeVO.getEmpId());
				}
				if(!StringUtils.isEmpty(employeeVO.getName())) {
					employee.setName(employeeVO.getName());
				}
				Employee empReturn = employeeRepository.saveAndFlush(employee);
				if(null != empReturn) {
					// Send Notification email
				}
				return EmployeeConstant.SUCCESS;

			} else {
				LOGGER.info("Employee not found");
				return EmployeeConstant.NOTFOUND;
			}

		} catch (Exception e) {
			LOGGER.error("Exception occured updating employee", e);
			return EmployeeConstant.FAILURE;
		}
	}

	

	@Override
	public String deleteEmployee(EmployeeVO employeeVO) {
		LOGGER.info("Start employee delete ");

		try {
			Optional<Employee> emp = employeeRepository.findById(Integer.parseInt(employeeVO.getId()));
			if (emp.isPresent()) {
				Employee employee = emp.get();
				
				employeeRepository.delete(employee);
				
				// Send Notification email 
				
				return EmployeeConstant.SUCCESS;

			} else {
				LOGGER.info("Employee not found for deletion ");
				return EmployeeConstant.NOTFOUND;
			}

		} catch (Exception e) {
			LOGGER.error("Exception occured deleting employee", e);
			return EmployeeConstant.FAILURE;
		}
	}

	@Override
	public Employee searchEmployeeByEmail(String email) {
		try {
			return employeeRepository.findByEmail(email);
		} catch(Exception e) {
			LOGGER.error("Exception occured searching employee", e);
		}
		return null;
	}

	@Override
	public List<Employee> searchEmployeeByName(String name) {
		try {
			return employeeRepository.findByName(name);
		} catch(Exception e) {
			LOGGER.error("Exception occured searching employee", e);
		}
		return null;
	}

	@Override
	public List<Employee> searchAllEmployeeByName(String name) {
		try {
			return employeeRepository.findByNameContains(name);
		} catch(Exception e) {
			LOGGER.error("Exception occured searching employee match", e);
		}
		return null;
	}

	@Override
	public List<Employee> searchEmployeeByNameAndActive(String name, String status) {
		try {
			return employeeRepository.findByNameAndStatus(name, Integer.parseInt(status));
		} catch(Exception e) {
			LOGGER.error("Exception occured searching employee with status", e);
		}
		return null;
	}

	@Override
	public String changeStatus(String id, String status) {
		LOGGER.info("Start employee status change ");

		try {
			Optional<Employee> emp = employeeRepository.findById(Integer.parseInt(id));
			if (emp.isPresent()) {
				Employee employee = emp.get();
				employee.setStatus(Integer.parseInt(status));
				Employee empReturn = employeeRepository.saveAndFlush(employee);
				if(null != empReturn) {
					// Send Notification email
				}
				return EmployeeConstant.SUCCESS;

			} else {
				LOGGER.info("Employee not found for status change");
				return EmployeeConstant.NOTFOUND;
			}

		} catch (Exception e) {
			LOGGER.error("Exception occured updating employee status", e);
			return EmployeeConstant.FAILURE;
		}
	}

}
